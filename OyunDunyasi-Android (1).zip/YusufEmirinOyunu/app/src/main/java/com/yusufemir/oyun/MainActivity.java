package com.yusufemir.oyun;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.speech.tts.TextToSpeech;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;
import android.speech.tts.UtteranceProgressListener;
import java.util.List;
import java.util.ArrayList;
import android.content.Intent;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import org.json.JSONArray;
import org.json.JSONObject;
import android.app.PendingIntent;
import android.content.pm.PackageInstaller;
import android.provider.Settings;
import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private PermissionRequest bekleyenIzin;
    private String[] bekleyenKaynak;
    private SpeechRecognizer dinleyici;
    private String bekleyenDinle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Oyun sırasında ekran kararmasın
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Çentikli ekranlarda da kenara kadar kullan
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        // Türkçe sesli okuma (telefonun kendi ses motoru)
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("tr", "TR"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(1.0f);
                tts.setPitch(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { bitti(id); }
                    @Override public void onError(String id) { bitti(id); }
                    @Override public void onStop(String id, boolean x) { bitti(id); }
                });
                // En doğal Türkçe sesi seç (yüksek kaliteli, mümkünse internetsiz)
                try {
                    android.speech.tts.Voice best = null; int bs = -1;
                    for (android.speech.tts.Voice v : tts.getVoices()) {
                        if (v.getLocale() == null || !"tr".equals(v.getLocale().getLanguage())) continue;
                        if (v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                        int sc = v.getQuality() * 2 - v.getLatency() + (v.isNetworkConnectionRequired() ? 0 : 50);
                        if (sc > bs) { bs = sc; best = v; }
                    }
                    if (best != null) tts.setVoice(best);
                } catch (Exception e) {}
            }
        });

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#dff1ff"));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#dff1ff"));
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        // Tam ekranda klavye açılınca oyun klavyenin üstüne kayar
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int alt;
            if (Build.VERSION.SDK_INT >= 30) alt = insets.getInsets(WindowInsets.Type.ime()).bottom;
            else alt = Math.max(0, insets.getSystemWindowInsetBottom() - insets.getStableInsetBottom());
            v.setPadding(0, 0, 0, alt);
            return insets;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidTTS");
        web.addJavascriptInterface(new SttBridge(), "AndroidSTT");
        web.addJavascriptInterface(new ScreenBridge(), "AndroidScreen");
        web.addJavascriptInterface(new UpdateBridge(), "AndroidUpdate");
        web.setWebViewClient(new WebViewClient());
        // Sesli konuşma: oyun mikrofon isteyince telefonun iznini sor
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    List<String> ist = new ArrayList<>(); List<String> izin = new ArrayList<>();
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) { ist.add(r); izin.add(Manifest.permission.RECORD_AUDIO); }
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) { ist.add(r); izin.add(Manifest.permission.CAMERA); }
                    }
                    if (ist.isEmpty()) { request.deny(); return; }
                    List<String> eksik = new ArrayList<>();
                    for (String p : izin) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) eksik.add(p);
                    if (eksik.isEmpty()) { request.grant(ist.toArray(new String[0])); return; }
                    bekleyenIzin = request; bekleyenKaynak = ist.toArray(new String[0]);
                    requestPermissions(eksik.toArray(new String[0]), 7);
                });
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        tamEkran();
        // Güncelleme: arka plan denetimi ve bildirim izni (Android 13+)
        Guncelleyici.kanal(this);
        Guncelleyici.planla(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
                && !Guncelleyici.ayar(this).getBoolean("bildirimSoruldu", false)) {
            Guncelleyici.ayar(this).edit().putBoolean("bildirimSoruldu", true).apply();
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);
        }
        bildirimdenGeldi(getIntent());
    }

    // Tam ekran: durum çubuğu ve alt tuşlar gizlenir, kenardan kaydırınca kısa süre görünür
    @SuppressWarnings("deprecation")
    private void tamEkran() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) tamEkran();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 8) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && bekleyenDinle != null) dinle(bekleyenDinle);
            else js("err", "9");
            bekleyenDinle = null;
            return;
        }
        if (code == 7 && bekleyenIzin != null) {
            // Verilen izinlere göre kaynakları aç (kamera reddedilse bile ses çalışsın)
            List<String> ver = new ArrayList<>();
            for (String r : bekleyenKaynak) {
                String p = PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) ? Manifest.permission.CAMERA : Manifest.permission.RECORD_AUDIO;
                if (checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) ver.add(r);
            }
            if (ver.isEmpty()) bekleyenIzin.deny(); else bekleyenIzin.grant(ver.toArray(new String[0]));
            bekleyenIzin = null; bekleyenKaynak = null;
        }
    }

    // Kitap Oku: telefonun konuşma tanıma motoru (Türkçe)
    private void js(String fn, String args) {
        final String code = "window.__yeoStt&&window.__yeoStt." + fn + "(" + args + ")";
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }
    private void dinle(String dil) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            bekleyenDinle = dil;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 8);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("err", "-1"); return; }
        if (dinleyici == null) {
            dinleyici = SpeechRecognizer.createSpeechRecognizer(this);
            dinleyici.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { js("ready", ""); }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int e) { js("err", String.valueOf(e)); }
                @Override public void onResults(Bundle b) { gonder(b, true); }
                @Override public void onPartialResults(Bundle b) { gonder(b, false); }
                @Override public void onEvent(int t, Bundle b) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, dil);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, dil);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L);
        try { dinleyici.cancel(); dinleyici.startListening(i); } catch (Exception e) { js("err", "-1"); }
    }
    private void gonder(Bundle b, boolean son) {
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r == null || r.isEmpty()) { if (son) js("err", "7"); return; }
        js("res", new JSONArray(r).toString() + "," + son);
    }
    private class ScreenBridge {
        @JavascriptInterface public void landscape(boolean on) {
            runOnUiThread(() -> setRequestedOrientation(on ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
        }
        @JavascriptInterface public void openUrl(String u) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u))); } catch (Exception e) {} });
        }
        @JavascriptInterface public String version() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
        }
    }
    private class SttBridge {
        @JavascriptInterface public boolean ok() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }
        @JavascriptInterface public void start(String dil) { runOnUiThread(() -> dinle(dil == null ? "tr-TR" : dil)); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (dinleyici != null) { try { dinleyici.cancel(); } catch (Exception e) {} } }); }
    }

    private void bitti(String id) {
        if (id == null || !id.startsWith("v")) return;
        final String code = "window.__ttsDone&&window.__ttsDone('" + id.replace("'", "") + "')";
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }
    private class Bridge {
        @JavascriptInterface
        public void speak(String text) {
            if (ttsReady && text != null) { tts.setPitch(1.0f); tts.setSpeechRate(1.0f); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yeo"); }
        }
        // Yapay zekâ oyuncuları: her biri kendi ses tonu ve hızıyla
        @JavascriptInterface
        public boolean speakVoice(String text, float pitch, float rate, String id) {
            if (!ttsReady || text == null) return false;
            tts.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
            tts.setSpeechRate(Math.max(0.6f, Math.min(1.4f, rate)));
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
            return true;
        }
        @JavascriptInterface
        public void stop() {
            if (tts != null) tts.stop();
        }
    }

    // Geri tuşu: oyunun içindeki geri / mola düğmesine basar, ana menüdeyse uygulamadan çıkar
    @Override
    public void onBackPressed() {
        String js = "(function(){var a=document.querySelector('.overlay.show');" +
                "var s=document.querySelector('.screen.active');" +
                "if(!s||s.id==='menu')return 'exit';" +
                "if(a)return 'stay';" +
                "var b=s.querySelector('.xback,#btnPause,[data-go=\"menu\"]');" +
                "if(b){b.click();return 'ok';}return 'exit';})()";
        web.evaluateJavascript(js, value -> {
            if (value != null && value.contains("exit")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (tts != null) tts.stop();
        if (dinleyici != null) { try { dinleyici.cancel(); } catch (Exception e) {} }
        web.onPause();
    }

    /* ---------- uygulama içinden güncelleme ---------- */
    private volatile String bekleyenApk;
    private volatile boolean indiriliyor = false;

    private void updJs(String k, String v) {
        final String code = "window.__upd&&window.__upd(" + JSONObject.quote(k) + "," + JSONObject.quote(v == null ? "" : v) + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void bildirimdenGeldi(Intent i) {
        if (i != null && i.getBooleanExtra("guncelle", false)) {
            i.removeExtra("guncelle");
            web.postDelayed(() -> web.evaluateJavascript("window.YEO_UPDATE&&YEO_UPDATE.check()", null), 2500);
        }
    }

    private void kur(String url) {
        if (indiriliyor) return;
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            bekleyenApk = url;
            updJs("izin", "");
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { updJs("err", "Ayarlar açılamadı"); }
            });
            return;
        }
        indiriliyor = true;
        new Thread(() -> {
            HttpURLConnection h = null;
            PackageInstaller.Session ses = null;
            try {
                URL u = new URL(url);
                for (int k = 0; k < 6; k++) {   // GitHub indirme adresi başka sunucuya yönlendirir
                    h = (HttpURLConnection) u.openConnection();
                    h.setInstanceFollowRedirects(false);
                    h.setConnectTimeout(20000); h.setReadTimeout(30000);
                    h.setRequestProperty("User-Agent", "OyunDunyasi");
                    int c = h.getResponseCode();
                    if (c >= 300 && c < 400) { String loc = h.getHeaderField("Location"); h.disconnect(); u = new URL(u, loc); continue; }
                    if (c != 200) throw new Exception("Sunucu cevabı " + c);
                    break;
                }
                long len = h.getContentLengthLong();
                PackageInstaller pi = getPackageManager().getPackageInstaller();
                PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                sp.setAppPackageName(getPackageName());
                if (len > 0) sp.setSize(len);
                int id = pi.createSession(sp);
                ses = pi.openSession(id);
                long top = 0; int son = -1;
                try (InputStream in = h.getInputStream(); OutputStream out = ses.openWrite("oyun.apk", 0, len > 0 ? len : -1)) {
                    byte[] buf = new byte[65536]; int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n); top += n;
                        int p = len > 0 ? (int) (top * 100 / len) : -1;
                        if (p != son) { son = p; updJs("prog", String.valueOf(p)); }
                    }
                    ses.fsync(out);
                }
                Intent cb = new Intent(MainActivity.this, MainActivity.class);
                cb.setAction("com.yusufemir.oyun.GUNCELLE_SONUC");
                cb.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
                PendingIntent pend = PendingIntent.getActivity(MainActivity.this, id, cb, fl);
                updJs("hazir", "");
                ses.commit(pend.getIntentSender());
                ses.close(); ses = null;
            } catch (Exception e) {
                if (ses != null) { try { ses.abandon(); } catch (Exception x) {} }
                updJs("err", String.valueOf(e.getMessage()));
            } finally {
                if (h != null) h.disconnect();
                indiriliyor = false;
            }
        }).start();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if ("com.yusufemir.oyun.GUNCELLE_SONUC".equals(intent.getAction())) {
            int st = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999);
            if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                Intent onay = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                if (onay != null) { try { startActivity(onay); } catch (Exception e) { updJs("err", "Kurulum ekranı açılamadı"); } }
            } else if (st != PackageInstaller.STATUS_SUCCESS) {
                String m = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                updJs("err", (st == PackageInstaller.STATUS_FAILURE_ABORTED ? "İptal edildi" : st == PackageInstaller.STATUS_FAILURE_CONFLICT ? "Çakışma: eski uygulamayı bir kez kaldırıp yeniden kur" : "Kurulamadı") + (m != null ? " (" + m + ")" : ""));
            }
            return;
        }
        bildirimdenGeldi(intent);
    }

    private class UpdateBridge {
        @JavascriptInterface public String version() { return Guncelleyici.surum(MainActivity.this); }
        @JavascriptInterface public void setRepo(String r) { if (r != null && r.contains("/") && !r.startsWith("__")) Guncelleyici.ayar(MainActivity.this).edit().putString("depo", r).apply(); }
        @JavascriptInterface public String repo() { return Guncelleyici.depo(MainActivity.this); }
        @JavascriptInterface public void install(String url) { kur(url); }
        @JavascriptInterface public void checkNow() { new Thread(() -> {
            String[] s = Guncelleyici.sonSurum(MainActivity.this);
            if (s == null) updJs("yok", "ag");
            else if (Guncelleyici.karsilastir(s[0], Guncelleyici.surum(MainActivity.this)) > 0) updJs("var", s[0] + "|" + s[1]);
            else updJs("yok", "guncel");
        }).start(); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bekleyenApk != null && (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls())) {
            String u = bekleyenApk; bekleyenApk = null; updJs("izinTamam", ""); kur(u);
        }
        web.onResume();
        tamEkran();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (dinleyici != null) dinleyici.destroy();
        web.destroy();
        super.onDestroy();
    }
}
