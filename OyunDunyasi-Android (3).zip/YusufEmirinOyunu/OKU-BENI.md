# Oyun Dünyası – Android uygulaması

Bu klasör hazır bir Android projesidir. İçinde oyunun kendisi (`app/src/main/assets/index.html`) ve onu telefonda açan küçük bir uygulama var. Sesli okuma telefonun kendi Türkçe ses motoruyla çalışır. Oyun internetsiz de oynanır.

## Bu sürümde (3.3)
- 👥 Arkadaş ekleme ve ad değiştirme sadece ana sayfada (👥 Arkadaşlarım, ✏️ Adım). Oyunların içinde sadece eklenmiş arkadaşlar çağrılır.
- 🔧 Tamirde vida ve somun sökerken ekran o vidaya yaklaşıyor; tornavida/anahtar dönüyor, vida dışarı çıkıp kutuya uçuyor.
- ✂️ Kâğıtla Etkinlik: evdeki malzemeleri seç, akıllı önerici 36 etkinlikten sana uygun olanı bulur (adım adım, sesli okuma, beğendiklerine göre öğrenir). Blok Dünyası'nda 💡 düğmesi Blok temalı etkinlikler önerir. Öneriler internetsiz, uygulamanın içinde hazırlanır.
- 🧟 Zombi Köylü: gece zombi ısırır, doktor korur, gözcü bakar; gündüz köy konuşur ve oylar. Eksik oyuncuları yapay zekâ oynar (konuşur, şüphelenir, yalan söyleyebilir). Arkadaşla iki cihazda oynanır.
- 💣 Bomba Kedi: kart çek, bomba kediyi çekme! Söndürücü, pas geç, saldır, karıştır, geleceği gör, rica et, kedi çiftleriyle kart çalma. 2-5 oyuncu, eksikler yapay zekâ, arkadaşla oynanır.
- 👫 Birlikte Oyna: harf oyunları, Kitap Oku, Market, Sabır, Kulak Ver, Bebeğimi Giydir, Hafıza ve Devre Kur artık arkadaşla aynı anda oynanıyor (kartlardaki 👫 düğmesi). Doğru cevaplar canlı puan tablosunda yarışır, sesli konuşma ve sohbet açık.

## Bu sürümde (3.2)
- 🐞 Devre Kur’da görevlere dokununca açılmama hatası düzeltildi.
- 🚗🔧 Gerçekçi Araba Tamirhanesi (❤️ 6 can): patlak lastik (bijon, kriko), akü değişimi (önce eksi kutup!), far ampulü, yağ değişimi (tapa, leğen, MAKS çizgisi), motor değişimi (takoz cıvataları, motor vinci).
- 🏠⚡ Yetişkin modunda Ev Elektrik Tesisatı (❤️ 6 can): priz montajı, anahtar ve tavan lambası (buat, klemens), sigorta panosu. Sigortayı kapatmadan kabloya dokunmak, yanlış uca bağlamak, yanlış sigorta seçmek can götürür.
- 🧸 Oyuncak Tamiri (❤️ 6 can): kumandalı araba (pillerin yönü), konuşan ayıcık (lehim).
- 🧱 Blok: 26 yeni blok (granit, mermer, kiremit, parke, fayans, kitaplık, renkli camlar, kabak, karpuz, kaktüs, ametist…), 10 kutulu çubuk, çantada arama ve ⭐ son kullanılanlar, 🎯 dünyadan blok kopyalama, kutuya basılı tutunca çanta açılır, klavye kısayolları (1-0, Q, E, R, M, fare tekerleği).

## Bu sürümde (3.1)
- ⚡ Devre oyununda yaş seçimi: 🧸 7 yaş (renkli, resimli), 🧒 9-10 yaş (Mühendis Çırağı: mavi devre tahtası, ölçü aleti, volt/amper/direnç, seri-paralel, VE/VEYA anahtarları; 8 görev), 🧑‍🔬 Yetişkin (Devre Laboratuvarı: şema sembolleri, canlı V/mA/mW tablosu, Ohm yasası, gerilim bölücü, LED ön direnci, güç, Kirchhoff, motor sürücü; 7 görev). Her yaşın ilerlemesi ayrı tutulur, Araba Tamirhanesi hepsinde var.
- 🧱 Blok: su kapalı bir çukura konunca çukuru konduğu seviyeye kadar tamamen doldurur.
- 💥 Patlat sekmesine 🧹 Alan kır ve 🧱 Alan doldur: iki köşeye dokun, aradaki bloklar kırılır ya da seçtiğin blokla dolar (en fazla 20x20x20).
- 🚗 Arabalar direksiyon ve gaz/fren pedallarıyla sürülüyor (uçak eskisi gibi çubukla).

## Bu sürümde (3.0)
- ⚡ Devre Kur: yeni parçalar (🧯 sigorta, 📯 korna, 🎚️ ışık ayarı, 🌗 ışık sensörü) ve 3 yeni görev (Sigorta korur, Işığı kıs aç, Gece lambası).
- 🚗🔧 Araba Tamirhanesi: 8 bozuk araba. Kopuk far kablosu, patlak ampul, kayıp korna düğmesi, atmış sigorta, ters akü, çalışmayan marş, ters dönen silecek, büyük bakım. Tamir edilince araba çalışıp gidiyor.
- 🧱 Blok: büyük ve küçük arabalarda koltuğa hangi yönden dokunursan dokun, araba farlarının olduğu ön tarafa doğru gider.

## Bu sürümde (2.9)
- 🔨 Tokmak (💥 Patlat sekmesinde): dokunduğun blok basılı tutmadan hemen kırılır, madenler çantaya girer.

## Bu sürümde (2.8)
- Uygulamanın adı **Oyun Dünyası**. Ana ekranın üstünde oyuncunun adıyla “…’ın Oyunu” yazıyor; ✏️ Adım düğmesiyle ad değişiyor.
- 🧱 Blok Dünyası yatay ekranda açılıyor.
- ⛏️ Madenler tek dokunuşla kırılmıyor: basılı tut, ortadaki halka dolunca kırılır. Kömür hızlı, elmas en yavaş.
- ♻️ Çantadaki Maden sekmesinden maden ocağı sıfırlanabiliyor (bütün madenler yerine gelir).
- 🗺️ Harita: önemli yerler, metro durakları ve lego arabalar görünür; birine ya da haritada bir yere dokunup ışınlan.
- 🐄 Hayvanlar: inek, domuz, koyun, tavuk, at, köpek. Gezerler, dokununca ses çıkarıp zıplarlar.
- 💥 Patlat sekmesi: TNT, Süper TNT (dokununca 3 saniye sonra patlar, yan yana olanlar zincirleme patlar), 🚀 roket atar, 🔆 yok edici ışın, ⛏️ dev kazma (3x3 kazar).

## Bu sürümde (2.7)
- 🧱 Blok Dünyası’nda yeni dünya 512x512 (eskisinin 4 katı) ve yerin altı çok derin: mağaralar, kömür, bakır, demir, altın ve elmas madenleri.
- ⛏️ Maden ocağı: dönen merdivenle kuyunun dibine in, tünellerde madenleri kır. Çantadaki ⛏️ Maden sekmesinden meşale, ray, demir/altın/elmas blok, süper motor, süper pil, kristal lamba ve altın kupa yap.
- 🚇 Metro: yolların altında 7 duraklı tren hattı. Durağa merdivenden in, 🚇 Bin’e bas, durakta 🚪 İn.
- 🔧 Tamir atölyesi: kırmızı tezgaha dokun, küçük lego parçalarıyla araba yap (ayna, geri al, hazır arabalar, garaja kaydet), sonra sür. Büyük bloklu arabalar da duruyor.
- 🏢 Fotoğraftaki mavi çizgili apartman: balkonlar, giriş, direk, çit; içinden merdivenle çatıya çıkılıyor.
- 💧 Su artık akıyor: düşer, yayılır, iki kaynak arası dolar, lavı taşa çevirir.
- Eski dünyalar aynen açılır; yenileri görmek için “Yeni dünya”ya bas.

## Bu sürümde (2.6)
- Oyunun adı “Yunus’un Oyunu” oldu (başlık ve telefondaki uygulama adı).

## Bu sürümde (2.5)
- Ayı Adası artık **Macera Adası**: ayı yerine insan kahramanlar (Yusuf, Ali, Elif, Deniz). Yüzleri, saçları, kıyafetleri ve sırt çantaları var; koşarken dizler ve dirsekler bükülüyor.
- **Kenara tutunma**: zıplayınca eller kenara değerse tutunur; ⬆️ ya da ileri itince tırmanır, geri çekince bırakır, sağa sola kayabilir.
- Çift zıplamada takla, uzun basınca daha yüksek zıplama, yumuşak hızlanma, kenardan düşerken kısa süre zıplayabilme.
- Bölümler daha zor ve çeşitli: tırmanma sütunları, dönen dikenli kütük, ateş fıskiyeleri, etrafında dönen platformlar, asansör, sallanan ip köprü, kovalayan düşmanlar.
- Yeni 4. bölüm **Volkan Adası** (3 Altın Bal ile açılır), sonunda dev canavar: duvara çarpınca sersemler, o zaman kafasına zıpla.

## Bu sürümde (2.4)
- 🎨 Çiz, Tahmin Et puanı: doğru bilen 3 puan, her yanlış tahmin 1 puan eksiltir (en az 1), çizen 1 puan. Doğru/yanlış sayıları skorda ve oyun sonunda görünür.

## Bu sürümde (2.3)
- 🎥 Araçta kamera: ekranı kaydırarak araç etrafında dön, yukarı/aşağı bak; 🎥 düğmesiyle Arkadan / Uzaktan / Önden bak / Yukarıdan.

## Bu sürümde (2.2)
- 🐻 Ayı Adası daha gerçekçi: güneşe göre gerçek gölgeler, ayıda kürk dokusu, yapraklarda ve çimende ayrıntı.
- 🗣️ Seslendirme: gereksiz konuşmalar kaldırıldı, aynı cümle tekrar tekrar okunmuyor; emojiler okunmuyor; en doğal Türkçe ses seçiliyor.
- 🧱 Blok Dünyası: yeni dünya 256x256 (eskisinin 4 katı); yollar, şehir, otopark, benzinlik, çiftlik, uzun pistli havalimanı, deniz kenarı.
- 🚛 Yeni araçlar: TIR, otobüs, itfaiye, polis, taksi, ambulans, spor araba, traktör. Sürüş daha stabil, yolda daha hızlı.

## Bu sürümde (2.1)
- 🐻 Ayı Macerası: adadaki mor kapılardan 3 bölüme gidilir (Çiçekli Orman, Karlı Tepeler, Kum Çölü).
- Uçan adalar, hareketli ve çöken platformlar, zıplatıcılar, düşmanlar (üstüne zıpla ya da 🌀 dön), sandıklar, 3 can kalbi, kontrol bayrakları.
- Her bölümde 3 kayıp civciv ve sonunda Altın Bal. Altın Bal sonraki kapıyı açar.
- 🎩 Şapka Dükkânı: toplanan paralarla 7 şapka; ayının başında görünür. Paralar artık kaydediliyor.

## Bu sürümde (2.0)
- 📖 Kitap Oku: yazıyı sesli oku, doğru okunan kelime yeşil olur. 15 kitap + kelime okuma. Telefonun konuşma tanıma motorunu kullanır (Google uygulaması gerekir).
- 🐻 Ayı Adası yenilendi: gökyüzü, dalgalı deniz, çimen, çiçekler, kelebekler, gölgeler, yeni evler.
- Adada yeni oyunlar: ⚽ Futbol (arkadaşla da), 🏁 Yarış, 🎈 Balon Patlatma, 📖 Kitap Evi.

## Bu sürümde (1.9)
- 🐻 Ayı Adası: ayınla adayı gez, evlerin kapısından oyunlara gir, arkadaşınla birlikte gez.
- 👫 Arkadaş listesi: arkadaşını bir kere ekle, sonra adına dokunup çağır. Kod yazmak yok.
- 🔄 Bağlantı koparsa kendiliğinden yeniden bağlanır; uygulama kapanırsa menüde "oyuna geri dön" çıkar.
- 🎤 Sesli konuşma ve 💬 sohbet (Kelime Zinciri, Taş Kağıt Makas). Uygulama ilk seferde mikrofon izni ister.
- 🧱 Blok Dünyası karşılıklı oynanıyor; yeni dünya 4 kat büyük: havalimanı, stadyum, havuz, göl, yanardağ, bilim parkı.

## Bu sürümde (1.8)
- Uygulama tam ekran açılıyor: durum çubuğu ve alt tuşlar gizli (kenardan kaydırınca görünür).

## Bu sürümde (1.7)
- Çiz, Tahmin Et: kolay/orta/zor seviyeler (300 kelime), seçeneksiz oyun (yazarak ya da sesli + Doğru/Yanlış/Pas), 10–180 sn süre.

## Bu sürümde (1.6)
- Yeni **Çiz, Tahmin Et**: iki cihazda canlı çizim ya da aynı cihazda sırayla.

## Bu sürümde (1.5)
- İhale Savaşı’na **Kart savaşı** eklendi; hayvan ve canavar sayısı 100’e çıktı; para ve süreler kurulum ekranından ayarlanıyor.

## Bu sürümde (1.4)
- Yeni **Blok Dünyası**: 3D açık dünya. Blok koy/kır, elektrik devresi kur, bloklardan araba ve uçak yapıp bin.

## Bu sürümde (1.3)
- Yeni **Küçük Mucit · Devre Kur**: 12 görev ve serbest atölye. Kablo çek, ampul yak, pervane döndür, zil çal.

## Bu sürümde (1.2)
- Bebeğimi Giydir artık 3D. İnternetsiz çalışır, parmakla kaydırınca bebek döner.
- Yeni **İhale Savaşı** modu: bilgisayara karşı, aynı cihazda iki kişi ya da iki cihazla oda koduyla.
- İki cihazlı oyun için iki telefonun da internete bağlı olması gerekir (aynı Wi-Fi en iyisi). Diğer her şey internetsiz çalışır.

## Yol 1: GitHub ile (bilgisayar gerekmez, telefondan da olur)
1. github.com adresinde ücretsiz bir hesap aç.
2. Sağ üstteki **+** → **New repository** de, bir ad ver (örnek: yusuf-oyun) ve **Create repository**'ye bas.
3. Açılan sayfada **uploading an existing file** bağlantısına bas. Bu klasördeki **her şeyi** (gizli `.github` klasörü dahil) sürükleyip bırak, sonra **Commit changes**'e bas.
   - `.github` klasörü yüklenmezse: **Add file → Create new file** de, ad kısmına `.github/workflows/apk.yml` yaz ve bu klasördeki aynı dosyanın içeriğini yapıştır.
4. Üstteki **Actions** sekmesine geç. “APK oluştur” işi 3–5 dakikada biter (yeşil tik).
5. İşin üstüne tıkla, en alttaki **Artifacts** bölümünden **yusuf-emirin-oyunu-apk**'yı indir. ZIP'i açınca içinden `app-debug.apk` çıkar.

## Yol 2: Android Studio ile
1. Android Studio'yu kur ve **Open** ile bu klasörü aç.
2. Gradle eşitlemesi bitince **Build → Build APK(s)**'ye bas.
3. APK şurada olur: `app/build/outputs/apk/debug/app-debug.apk`

## Telefona kurmak
APK'yı telefona at ve dokun. “Bilinmeyen kaynaklardan yükleme” izni sorarsa izin ver.
Play Store dışından kurulduğu için Play Protect uyarı gösterebilir, **Yine de yükle** demen yeterli.

## Sesli okuma çalışmazsa
Ayarlar → Erişilebilirlik (veya Sistem → Dil) → **Metin okuma çıkışı** → Google Konuşma Hizmetleri → Türkçe ses verisini indir.
