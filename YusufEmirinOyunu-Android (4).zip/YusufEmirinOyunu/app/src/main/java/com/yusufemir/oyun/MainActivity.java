package com.yusufemir.oyun;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.speech.tts.TextToSpeech;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;
import java.util.ArrayList;
import android.content.Intent;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import org.json.JSONArray;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private PermissionRequest bekleyenIzin;
    private SpeechRecognizer dinleyici;
    private String bekleyenDinle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Oyun sırasında ekran kararmasın
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Çentikli ekranlarda da kenara kadar kullan
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        // Türkçe sesli okuma (telefonun kendi ses motoru)
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("tr", "TR"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(1.0f);
                tts.setPitch(1.0f);
                // En doğal Türkçe sesi seç (yüksek kaliteli, mümkünse internetsiz)
                try {
                    android.speech.tts.Voice best = null; int bs = -1;
                    for (android.speech.tts.Voice v : tts.getVoices()) {
                        if (v.getLocale() == null || !"tr".equals(v.getLocale().getLanguage())) continue;
                        if (v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                        int sc = v.getQuality() * 2 - v.getLatency() + (v.isNetworkConnectionRequired() ? 0 : 50);
                        if (sc > bs) { bs = sc; best = v; }
                    }
                    if (best != null) tts.setVoice(best);
                } catch (Exception e) {}
            }
        });

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#dff1ff"));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#dff1ff"));
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        // Tam ekranda klavye açılınca oyun klavyenin üstüne kayar
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int alt;
            if (Build.VERSION.SDK_INT >= 30) alt = insets.getInsets(WindowInsets.Type.ime()).bottom;
            else alt = Math.max(0, insets.getSystemWindowInsetBottom() - insets.getStableInsetBottom());
            v.setPadding(0, 0, 0, alt);
            return insets;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidTTS");
        web.addJavascriptInterface(new SttBridge(), "AndroidSTT");
        web.setWebViewClient(new WebViewClient());
        // Sesli konuşma: oyun mikrofon isteyince telefonun iznini sor
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean ses = false;
                    for (String r : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) ses = true;
                    if (!ses) { request.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        bekleyenIzin = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
                    }
                });
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        tamEkran();
    }

    // Tam ekran: durum çubuğu ve alt tuşlar gizlenir, kenardan kaydırınca kısa süre görünür
    @SuppressWarnings("deprecation")
    private void tamEkran() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) tamEkran();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 8) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && bekleyenDinle != null) dinle(bekleyenDinle);
            else js("err", "9");
            bekleyenDinle = null;
            return;
        }
        if (code == 7 && bekleyenIzin != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED)
                bekleyenIzin.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else bekleyenIzin.deny();
            bekleyenIzin = null;
        }
    }

    // Kitap Oku: telefonun konuşma tanıma motoru (Türkçe)
    private void js(String fn, String args) {
        final String code = "window.__yeoStt&&window.__yeoStt." + fn + "(" + args + ")";
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }
    private void dinle(String dil) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            bekleyenDinle = dil;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 8);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("err", "-1"); return; }
        if (dinleyici == null) {
            dinleyici = SpeechRecognizer.createSpeechRecognizer(this);
            dinleyici.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { js("ready", ""); }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int e) { js("err", String.valueOf(e)); }
                @Override public void onResults(Bundle b) { gonder(b, true); }
                @Override public void onPartialResults(Bundle b) { gonder(b, false); }
                @Override public void onEvent(int t, Bundle b) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, dil);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, dil);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L);
        try { dinleyici.cancel(); dinleyici.startListening(i); } catch (Exception e) { js("err", "-1"); }
    }
    private void gonder(Bundle b, boolean son) {
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r == null || r.isEmpty()) { if (son) js("err", "7"); return; }
        js("res", new JSONArray(r).toString() + "," + son);
    }
    private class SttBridge {
        @JavascriptInterface public boolean ok() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }
        @JavascriptInterface public void start(String dil) { runOnUiThread(() -> dinle(dil == null ? "tr-TR" : dil)); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (dinleyici != null) { try { dinleyici.cancel(); } catch (Exception e) {} } }); }
    }

    private class Bridge {
        @JavascriptInterface
        public void speak(String text) {
            if (ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yeo");
        }
        @JavascriptInterface
        public void stop() {
            if (tts != null) tts.stop();
        }
    }

    // Geri tuşu: oyunun içindeki geri / mola düğmesine basar, ana menüdeyse uygulamadan çıkar
    @Override
    public void onBackPressed() {
        String js = "(function(){var a=document.querySelector('.overlay.show');" +
                "var s=document.querySelector('.screen.active');" +
                "if(!s||s.id==='menu')return 'exit';" +
                "if(a)return 'stay';" +
                "var b=s.querySelector('.xback,#btnPause,[data-go=\"menu\"]');" +
                "if(b){b.click();return 'ok';}return 'exit';})()";
        web.evaluateJavascript(js, value -> {
            if (value != null && value.contains("exit")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (tts != null) tts.stop();
        if (dinleyici != null) { try { dinleyici.cancel(); } catch (Exception e) {} }
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        tamEkran();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (dinleyici != null) dinleyici.destroy();
        web.destroy();
        super.onDestroy();
    }
}
