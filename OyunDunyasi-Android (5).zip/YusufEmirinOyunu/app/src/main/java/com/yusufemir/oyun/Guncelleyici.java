package com.yusufemir.oyun;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobScheduler;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** GitHub'daki son sürümü denetler, yeni sürüm varsa bildirim gösterir. */
public final class Guncelleyici {
    static final String VARSAYILAN_DEPO = "madenfaaliyetraporu-dotcom/yusuf-oyun";
    static final String KANAL = "guncelleme";
    static final int IS_NO = 4242;

    private Guncelleyici() {}

    static SharedPreferences ayar(Context c) { return c.getSharedPreferences("guncelleme", Context.MODE_PRIVATE); }

    static String depo(Context c) {
        String r = ayar(c).getString("depo", "");
        return (r == null || r.isEmpty() || r.startsWith("__")) ? VARSAYILAN_DEPO : r;
    }

    static String surum(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; } catch (Exception e) { return "0"; }
    }

    static int karsilastir(String a, String b) {
        String[] x = a.replaceFirst("^v", "").split("\\."), y = b.replaceFirst("^v", "").split("\\.");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = i < x.length ? sayi(x[i]) : 0, q = i < y.length ? sayi(y[i]) : 0;
            if (p != q) return p - q;
        }
        return 0;
    }
    private static int sayi(String s) { try { return Integer.parseInt(s.replaceAll("[^0-9]", "")); } catch (Exception e) { return 0; } }

    /** {surum, apk adresi} ya da hata/yoksa null */
    static String[] sonSurum(Context c) {
        HttpURLConnection h = null;
        try {
            h = (HttpURLConnection) new URL("https://api.github.com/repos/" + depo(c) + "/releases/latest").openConnection();
            h.setConnectTimeout(15000); h.setReadTimeout(15000);
            h.setRequestProperty("Accept", "application/vnd.github+json");
            h.setRequestProperty("User-Agent", "OyunDunyasi");
            if (h.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"))) {
                String l; while ((l = r.readLine()) != null) sb.append(l);
            }
            JSONObject j = new JSONObject(sb.toString());
            String v = j.optString("tag_name", "").replaceFirst("^v", "");
            String url = j.optString("html_url", "");
            JSONArray as = j.optJSONArray("assets");
            if (as != null) for (int i = 0; i < as.length(); i++) {
                JSONObject a = as.getJSONObject(i);
                if (a.optString("name", "").toLowerCase().endsWith(".apk")) { url = a.optString("browser_download_url", url); break; }
            }
            if (v.isEmpty()) return null;
            return new String[]{v, url};
        } catch (Exception e) {
            return null;
        } finally { if (h != null) h.disconnect(); }
    }

    static void kanal(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(KANAL) == null) {
                NotificationChannel ch = new NotificationChannel(KANAL, "Güncellemeler", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Oyun Dünyası'nın yeni sürümü çıkınca haber verir");
                nm.createNotificationChannel(ch);
            }
        }
    }

    static void bildir(Context c, String v) {
        kanal(c);
        Intent i = new Intent(c, MainActivity.class);
        i.putExtra("guncelle", true);
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent p = PendingIntent.getActivity(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, KANAL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.stat_sys_download_done)
         .setContentTitle("🆕 Oyun Dünyası " + v + " hazır!")
         .setContentText("Yeni oyunlar ve düzeltmeler var. Güncellemek için dokun.")
         .setContentIntent(p)
         .setAutoCancel(true);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        try { if (nm != null) nm.notify(7001, b.build()); } catch (SecurityException e) { /* bildirim izni yok */ }
    }

    /** Arka plan denetimi yok: 3.15'ten kalan zamanlanmış işi varsa iptal et */
    static void planla(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js != null) js.cancel(IS_NO);
        } catch (Exception e) { }
    }

    /** Denetle; yeni sürüm varsa ve daha önce haber verilmediyse bildir */
    static void denetleVeBildir(Context c) {
        String[] s = sonSurum(c);
        if (s == null) return;
        if (karsilastir(s[0], surum(c)) <= 0) return;
        SharedPreferences a = ayar(c);
        if (s[0].equals(a.getString("bildirilen", ""))) return;
        a.edit().putString("bildirilen", s[0]).apply();
        bildir(c, s[0]);
    }
}
