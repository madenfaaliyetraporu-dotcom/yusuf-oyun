package com.yusufemir.oyun;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Birkaç saatte bir GitHub'a bakar, yeni sürüm varsa bildirim gönderir. */
public class GuncellemeIsi extends JobService {
    @Override
    public boolean onStartJob(final JobParameters p) {
        new Thread(() -> {
            try { Guncelleyici.denetleVeBildir(getApplicationContext()); } catch (Exception e) {}
            jobFinished(p, false);
        }).start();
        return true;
    }
    @Override
    public boolean onStopJob(JobParameters p) { return true; }
}
