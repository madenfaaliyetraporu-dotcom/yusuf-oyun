# Yusuf Emir’in Oyunu – Android uygulaması

Bu klasör hazır bir Android projesidir. İçinde oyunun kendisi (`app/src/main/assets/index.html`) ve onu telefonda açan küçük bir uygulama var. Sesli okuma telefonun kendi Türkçe ses motoruyla çalışır. Oyun internetsiz de oynanır.

## Bu sürümde (2.4)
- 🎨 Çiz, Tahmin Et puanı: doğru bilen 3 puan, her yanlış tahmin 1 puan eksiltir (en az 1), çizen 1 puan. Doğru/yanlış sayıları skorda ve oyun sonunda görünür.

## Bu sürümde (2.3)
- 🎥 Araçta kamera: ekranı kaydırarak araç etrafında dön, yukarı/aşağı bak; 🎥 düğmesiyle Arkadan / Uzaktan / Önden bak / Yukarıdan.

## Bu sürümde (2.2)
- 🐻 Ayı Adası daha gerçekçi: güneşe göre gerçek gölgeler, ayıda kürk dokusu, yapraklarda ve çimende ayrıntı.
- 🗣️ Seslendirme: gereksiz konuşmalar kaldırıldı, aynı cümle tekrar tekrar okunmuyor; emojiler okunmuyor; en doğal Türkçe ses seçiliyor.
- 🧱 Blok Dünyası: yeni dünya 256x256 (eskisinin 4 katı); yollar, şehir, otopark, benzinlik, çiftlik, uzun pistli havalimanı, deniz kenarı.
- 🚛 Yeni araçlar: TIR, otobüs, itfaiye, polis, taksi, ambulans, spor araba, traktör. Sürüş daha stabil, yolda daha hızlı.

## Bu sürümde (2.1)
- 🐻 Ayı Macerası: adadaki mor kapılardan 3 bölüme gidilir (Çiçekli Orman, Karlı Tepeler, Kum Çölü).
- Uçan adalar, hareketli ve çöken platformlar, zıplatıcılar, düşmanlar (üstüne zıpla ya da 🌀 dön), sandıklar, 3 can kalbi, kontrol bayrakları.
- Her bölümde 3 kayıp civciv ve sonunda Altın Bal. Altın Bal sonraki kapıyı açar.
- 🎩 Şapka Dükkânı: toplanan paralarla 7 şapka; ayının başında görünür. Paralar artık kaydediliyor.

## Bu sürümde (2.0)
- 📖 Kitap Oku: yazıyı sesli oku, doğru okunan kelime yeşil olur. 15 kitap + kelime okuma. Telefonun konuşma tanıma motorunu kullanır (Google uygulaması gerekir).
- 🐻 Ayı Adası yenilendi: gökyüzü, dalgalı deniz, çimen, çiçekler, kelebekler, gölgeler, yeni evler.
- Adada yeni oyunlar: ⚽ Futbol (arkadaşla da), 🏁 Yarış, 🎈 Balon Patlatma, 📖 Kitap Evi.

## Bu sürümde (1.9)
- 🐻 Ayı Adası: ayınla adayı gez, evlerin kapısından oyunlara gir, arkadaşınla birlikte gez.
- 👫 Arkadaş listesi: arkadaşını bir kere ekle, sonra adına dokunup çağır. Kod yazmak yok.
- 🔄 Bağlantı koparsa kendiliğinden yeniden bağlanır; uygulama kapanırsa menüde "oyuna geri dön" çıkar.
- 🎤 Sesli konuşma ve 💬 sohbet (Kelime Zinciri, Taş Kağıt Makas). Uygulama ilk seferde mikrofon izni ister.
- 🧱 Blok Dünyası karşılıklı oynanıyor; yeni dünya 4 kat büyük: havalimanı, stadyum, havuz, göl, yanardağ, bilim parkı.

## Bu sürümde (1.8)
- Uygulama tam ekran açılıyor: durum çubuğu ve alt tuşlar gizli (kenardan kaydırınca görünür).

## Bu sürümde (1.7)
- Çiz, Tahmin Et: kolay/orta/zor seviyeler (300 kelime), seçeneksiz oyun (yazarak ya da sesli + Doğru/Yanlış/Pas), 10–180 sn süre.

## Bu sürümde (1.6)
- Yeni **Çiz, Tahmin Et**: iki cihazda canlı çizim ya da aynı cihazda sırayla.

## Bu sürümde (1.5)
- İhale Savaşı’na **Kart savaşı** eklendi; hayvan ve canavar sayısı 100’e çıktı; para ve süreler kurulum ekranından ayarlanıyor.

## Bu sürümde (1.4)
- Yeni **Blok Dünyası**: 3D açık dünya. Blok koy/kır, elektrik devresi kur, bloklardan araba ve uçak yapıp bin.

## Bu sürümde (1.3)
- Yeni **Küçük Mucit · Devre Kur**: 12 görev ve serbest atölye. Kablo çek, ampul yak, pervane döndür, zil çal.

## Bu sürümde (1.2)
- Bebeğimi Giydir artık 3D. İnternetsiz çalışır, parmakla kaydırınca bebek döner.
- Yeni **İhale Savaşı** modu: bilgisayara karşı, aynı cihazda iki kişi ya da iki cihazla oda koduyla.
- İki cihazlı oyun için iki telefonun da internete bağlı olması gerekir (aynı Wi-Fi en iyisi). Diğer her şey internetsiz çalışır.

## Yol 1: GitHub ile (bilgisayar gerekmez, telefondan da olur)
1. github.com adresinde ücretsiz bir hesap aç.
2. Sağ üstteki **+** → **New repository** de, bir ad ver (örnek: yusuf-oyun) ve **Create repository**'ye bas.
3. Açılan sayfada **uploading an existing file** bağlantısına bas. Bu klasördeki **her şeyi** (gizli `.github` klasörü dahil) sürükleyip bırak, sonra **Commit changes**'e bas.
   - `.github` klasörü yüklenmezse: **Add file → Create new file** de, ad kısmına `.github/workflows/apk.yml` yaz ve bu klasördeki aynı dosyanın içeriğini yapıştır.
4. Üstteki **Actions** sekmesine geç. “APK oluştur” işi 3–5 dakikada biter (yeşil tik).
5. İşin üstüne tıkla, en alttaki **Artifacts** bölümünden **yusuf-emirin-oyunu-apk**'yı indir. ZIP'i açınca içinden `app-debug.apk` çıkar.

## Yol 2: Android Studio ile
1. Android Studio'yu kur ve **Open** ile bu klasörü aç.
2. Gradle eşitlemesi bitince **Build → Build APK(s)**'ye bas.
3. APK şurada olur: `app/build/outputs/apk/debug/app-debug.apk`

## Telefona kurmak
APK'yı telefona at ve dokun. “Bilinmeyen kaynaklardan yükleme” izni sorarsa izin ver.
Play Store dışından kurulduğu için Play Protect uyarı gösterebilir, **Yine de yükle** demen yeterli.

## Sesli okuma çalışmazsa
Ayarlar → Erişilebilirlik (veya Sistem → Dil) → **Metin okuma çıkışı** → Google Konuşma Hizmetleri → Türkçe ses verisini indir.
