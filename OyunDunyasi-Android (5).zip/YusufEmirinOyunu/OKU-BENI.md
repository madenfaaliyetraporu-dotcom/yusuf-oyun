# Oyun Dünyası – Android uygulaması

Bu klasör hazır bir Android projesidir. İçinde oyunun kendisi (`app/src/main/assets/index.html`) ve onu telefonda açan küçük bir uygulama var. Sesli okuma telefonun kendi Türkçe ses motoruyla çalışır. Oyun internetsiz de oynanır.

## Bu sürümde (3.16)
- 🔄 **Güncelleme sadece uygulama açılırken sorulur.** Uygulama kapalıyken arka planda hiçbir şey denetlenmez, bildirim gelmez. Ayarlar'da **🔄 Güncellemeler → Denetle** düğmesi var.
- 🧱 **LEGO Ustası:** modeller artık 12×12 ile 20×20 arası numaralı bir **tabla** üzerinde gösterilir; topuz boşlukları ve numaraları görünür.
- 🔗 Her katın bir önceki katla **kenetlenmesi** denetlenir; ayrı kalan gövde parçaları büyük parçalarla birleştirilir.
- ⬆️ Adım adım yapımda **üstten kat planı** var.
- 🧩 Model sayısı arttı (itfaiye, ambulans, buldozer, apartman, market, pasta, dondurma, kurbağa, kaplumbağa…).
- ✅ Parça listesinde sadece **elindeki parçalar** görünür; **➕ Parça ekle** ile hepsi açılır.

## 3.15 — uygulamanın kendi güncelleyicisi
- Obtainium'a gerek yok: uygulama GitHub'daki **Yayınlar** sayfasına kendisi bakar.
- **Güncelle** düğmesine dokununca yeni sürüm oyunun içinden indirilir, Android'in kurulum ekranı açılır, **Güncelle**'ye basarsın. Kayıtlar silinmez.
- İlk seferde Android bir kerelik “Bu kaynaktan izin ver” izni ister.

## ⚠️ Güncelleme (3.14 ile değişti) — mutlaka oku
Eskiden her derlemede GitHub uygulamayı **farklı, rastgele bir anahtarla** imzalıyordu. Android bu yüzden yeni sürümü “başka bir uygulama” sanıp **“paket çakışıyor”** diyordu.
Artık projede sabit bir imza anahtarı var (`app/oyun-dunyasi.keystore`). Bu dosyayı silme, değiştirme.
1. **Sadece bir kere:** telefondaki eski Oyun Dünyası'nı kaldır, 3.14'ü kur. (Eski sürümün anahtarı farklı olduğu için bu bir kereye mahsus gerekir; eski kayıtlar silinir.)
2. Bundan sonra her yeni sürüm eskisinin **üstüne güncelleme olarak** kurulur, kayıtların korunur.
3. GitHub'a her yüklediğinde Actions APK'yı derler ve deponun **Releases (Sürümler)** bölümünde yayınlar (ör. `v3.14`).
4. **Otomatik soru:** uygulama açılınca GitHub'daki son sürüme bakar. Yeni sürüm varsa “🆕 Yeni sürüm hazır — İndir ve güncelle” diye sorar. Bunun için GitHub deposunun **herkese açık (public)** olması gerekir.
5. İstersen ücretsiz **Obtainium** uygulamasını kur, GitHub deponun adresini ekle: yeni sürümleri kendisi bulur, bildirim gönderir ve tek dokunuşla günceller.

## Bu sürümde (3.14) — yeraltı kömür ocağı ve üretim hattı
- ⛏️ Yeraltında **mekanize Kömür Ocağı**: dünyanda kendiliğinden açılır (haritada “⛏️ Kömür ocağı”). Yüzeydeki kuleden **asansörle** aşağı in. Kalın kömür damarı, ahşap tavan destekleri, lambalar.
- 🏭 Blok modeli üretim hattı: 3 **Kazıcı makine** damarı kazar → **Konveyör bantlar** ürünleri taşır → **Kırıcı** kömür madenini kırar (2 kömür), taşı çakıla çevirir → **Fırın** kumdan cam, 4 demirden demir blok yapar → **Üretim deposu** her şeyi çantana ekler. Ürünler bantta gerçekten hareket eder.
- ⚡ Hat elektrikle çalışır: pil + anahtar. Anahtarı kapatınca hat durur.
- Kendi hattını kur: bant ve kazıcı baktığın yöne doğru konur. Bant üstündeki oklar akış yönünü gösterir.
- 🏭 Çantada yeni **Makine** sayfası: konveyör bant, kazıcı, kırıcı, fırın, üretim deposu, vinç kolu, vinç makarası, döner tabla, asansör, asansör katı, Yapı Market tezgâhı; hazır **Kömür ocağı**, **Döner vinç**, **Yapı Market**.
- ⭐ Sol tarafta **sık kullanılan bloklar**: en çok koyduğun bloklar otomatik sıralanır, dokunup eline al. ⭐ düğmesi paneli açar/kapatır.
- Blok Dünyası artık 255 çeşit bloğa kadar destekliyor (eski kayıtlar sorunsuz açılır).

## Bu sürümde (3.13) — Yapı Market, kamyon, 360° vinç, yapay zekâ Lego tasarımcısı
- 🏗️ Vinç artık 360° dönüyor: kulenin herhangi bir yerine (altına ya da tepesine) **Döner tabla** bloğu koy; tablanın üstündeki her şey (kol, makara, karşı ağırlık) ⟲ ⟳ düğmeleriyle döner. Bir yere çarpacaksa durur. Çıkınca vinç en yakın düz yöne oturur. Araç menüsünde hazır **Döner vinç** de var.
- 🏪 **Yapı Market**: dünyanda başlangıca yakın bir yapı marketi kendiliğinden açılır (haritada “🏪 Yapı Market”). Tezgâha dokun:
  - 🛒 Tuğla, tahta, beton, cam, renkli bloklar, vinç parçaları, asansör, motor… satın al (×4 – ×64).
  - 🚚 **Kamyona yükle**: yükleme alanındaki kamyonun kasasına bloklar dizilir. Koltuğa dokun, bin, inşaata götür; inince yük yerinde kalır. Vinçle kasadan indirebilirsin (vinç sadece yükü alır, kamyonu değil).
  - 📦 **Yükleme alanına**: bloklar tahta palet üstünde yere konur, vinçle taşı.
  - 🎒 Hayatta kalma modunda doğrudan çantana.
  - 💎 Madenlerini sat, para kazan (yıldız taşı 400 ₺!). Başlangıçta 500 ₺, her gün 100 ₺ harçlık.
- 🚚 Yeni araç: **Kamyon** (tahta kasalı). Araç menüsünden koyabilirsin.
- 🧱 Lego Ustası artık sabit model kullanmıyor: yapay zekâ her “Bana model öner”de 48 yepyeni model tasarlıyor (21 çeşit: araba, otobüs, tren, uçak, roket, gemi, ev, gökdelen, deniz feneri, kale, köprü, hayvanlar, kuşlar, robot, kahraman, kardan adam, ağaç, bitki, mobilya, mozaik, heykel, Blok Dünyası blokları). Boyları ve şekilleri her seferinde farklı, büyüklüğü senin parça sayına göre ayarlanır. Her tasarımı renk, parça ve fizik açısından kontrol edip en iyilerini gösterir.

## Bu sürümde (3.12) — Lego fizik kuralı
- 🧱 Lego Ustası artık fizik kuralına uyuyor: her parça, altındaki ya da üstündeki bir parçaya topuzla takılı olmalı ve bu bağ yere kadar inmeli. Hiçbir parça askıda kalmaz.
- Boşluğa taşan yerlerde (kanat, gaga, çatı saçağı) önce bu yeri alttaki sağlam parçaya bağlayan uzun bir parça seçer (köprü).
- Parçaları duvar örer gibi kaydırarak dizer: üstteki parça alttaki iki parçaya basar, model sağlam olur ve kolay dağılmaz.
- Yine de askıda kalan yer olursa altına destek sütunu koyar ("🔩 destek parçası") ve adımlarda söyler.
- Çok destek gerektiren modeller daha az önerilir. Fizik kontrolünün sonucu öneri metninde yazar.

## Bu sürümde (3.11) — Lego Ustası'nda tüm parçalar
- 🧱 Artık sadece tekli ve dörtlü değil, tüm tuğla boyları var: Tekli 1×1, İkili 1×2, Üçlü 1×3, Uzun dörtlü 1×4, 1×6, 1×8, Dörtlü 2×2, Altılı 2×3, Sekizli 2×4, 2×6, 2×8 ve 4×4.
- ➕ Parça ekle: listede olmayan bir parçan varsa topuzlarını sayıp (en × boy) kendin ekle, istersen ad ver. ✕ ile silebilirsin.
- Önce parça türünü seç, sonra her renkten kaç tane olduğunu yaz. Her parçanın toplamı üstünde görünür.
- Yapay zekâ model kurarken büyük parçaları (sekizli, altılı, uzun) önce kullanır, kalan yerleri küçük parçalarla doldurur. Adımlarda her parçanın boyu yazar.
- Eski sayıların korunur (tekli ve dörtlü sayıların yeni listeye taşındı).

## Bu sürümde (3.10) — Blok makineleri ve Lego Ustası
- 🚁 Blok Dünyası'na helikopter: yeni **Pervane** bloğu. Koltuk + motor + pil + en üste pervane koy, koltuğa dokunup bin. 🔥 Motor, ⬆️ Yüksel, ⬇️ Alçal; çubukla ileri git ve dön. Pervane gerçekten döner. Araç menüsünde hazır helikopter de var.
- 🛗 Asansör: **Asansör** bloğunun üstüne çık, ⬆️/⬇️ düğmesine bas. Kat olan yerlerde (yanında zemin ya da **Asansör katı** bloğu) durur. Uzaktan dokununca asansör senin katına gelir. Çelik halatları görünür.
- 🏗️ Halatlı vinç: **Vinç kolu** bloklarıyla kule ve uzun kol yap, kolun altına **Vinç makarası** koy, dokun. ◀ ▶ makarayı kaydırır, ⬇️ ⬆️ ince örgülü halatı indirir (blok değil, gerçek halat). Kancayı bir yapıya değdir, ✊ Tut: 150 bloğa kadar kaldırıp taşır, 🖐️ Bırak.
- ⛏️ Hayatta kalma modu (Çanta → Maden): bloklar sayılı olur. Kırdığın her şey çantana gelir, gerisini tariflerle yaparsın: odundan tahta, kum + kömürden cam, demir + bakırdan motor, pervane, asansör, vinç… 60'tan fazla tarif. Yaratıcı moda istediğin an dönebilirsin.
- 💎 Yeni nadir madenler: Zümrüt ve Yakut (çok nadir), 🌟 Yıldız taşı (efsane, en dipte, ışık saçar). Elmas da artık daha nadir. Madenler artık küçük dünyalarda da var.
- 🧱 Yeni: **Lego Ustası** (Evde etkinlik bölümünde). Evdeki legolarının rengine göre tekli (1×1) ve dörtlü (2×2) parça sayısını yaz (istersen ikili, 1×4, 2×4 de). Yapay zekâ 26 modelin hangisini senin parçalarınla yapabileceğini hesaplar: renkleri parçalarına göre seçer, eksik rengi yakın renkle değiştirir, büyük boy yapıp yapamayacağına bakar. Modeli 3D gösterir, kat kat adım adım anlatır, sesli okur. Araba, kamyon, uçak, roket, robot, ev, kale, hayvanlar, Creeper, TNT, mozaikler ve senin adının baş harfi.

## Bu sürümde (3.9) — profesyonel 3D grafik (three.js)
- Üç 3D oyun, oyun dünyasında yaygın kullanılan **three.js** 3D kütüphanesiyle baştan çizildi: gerçek gölgeler, fiziksel ışık (PBR), yansıyan parlak boyalar, HDR ortam ışığı. Her şey uygulamanın içinde, internet gerekmez.
- 🏎️ Hız Yarışı: gerçek **Ferrari 458** 3D modeli (cilalı boya, cam, krom jantlar, dönen tekerlekler), ışıklı gökdelenli gece şehri, neon panolar, nitro alevleri.
- 🚛 TIR Simülatörü: gerçekçi gökyüzü ve güneş, çimenli tepeler, ormanlar, rüzgâr gülleri, şeritli asfalt, beton orta refüj, bariyerler, yeşil yön tabelaları (km yazılı), 90 hız levhaları, depolarda park etmiş dorseler. Yeni TIR: yuvarlak hatlı metalik kabin, krom ızgara ve egzozlar, aynalar, çift tekerlekler; "OYUN DÜNYASI LOJİSTİK" brandalı dorse. Kabin içi görünümde gösterge paneli ve direksiyon.
- 🦎 Kameleon Saklambaç: yeni pürüzsüz bukalemunlar (pullu deri, kıvrık kuyruk, dönen gözler, yürüme animasyonu, renge yavaşça bürünme), parlak zeminli renkli oda, sarkıt lambalar, gerçek eşyalar (koltuk, kitaplık, saksı bitkisi, varil, masa…). Ebe ararken oda kararır, el feneri gerçek ışık ve gölge yapar.
- Telefon yavaşlarsa oyunlar gölgeleri kendiliğinden kapatıp akıcı kalır.
- Uygulama boyutu 3D modeller yüzünden biraz büyüdü (~7 MB).
- Emeği geçenler: Ferrari 458 Italia modeli – vicent091036 (CC BY 4.0). three.js (MIT).

## Bu sürümde (3.8) — gerçek 3D oyunlar
- Uygulamaya kendi 3D motorumuz eklendi (WebGL): ışık, parlak araba boyası, sis, gökyüzü, ışık parlamaları, parçacık efektleri, el feneri ışığı. İnternet gerekmez.
- 🏎️ Hız Yarışı 3D (Asphalt tarzı): gece şehir pisti, ışıklı gökdelenler, neon panolar, sokak lambaları, mavi-beyaz bariyerler. 6 araba seçeneği, drift (fren + direksiyon) ile dolan nitro, mavi alevler, kıvılcım, hız çizgileri, takip kamerası, harita, otomatik gaz ve telefonu çevirerek sürme seçeneği. Arkadaşla iki cihazda karşılıklı, boş yerlere bot.
- 🚛 TIR Simülatörü 3D (Euro Truck tarzı): tepeli arazi, otoyol, ormanlar, rüzgâr gülleri, trafik, iki depo. Gerçekçi dorse fiziği (geri manevra, makaslama), sürükleyerek çevrilen direksiyon, gaz/fren pedalı, frene basılı tutunca geri vites ve bip sesi, sinyaller, farlar, korna, dizel motor sesi, 3 kamera (arka, kabin içi, yukarıdan), GPS. Yükü al, diğer depoya götür, dorseyi işaretli park yerine yanaştır, 🅿️ Teslim et → para kazan (hasar düşer). Arkadaşla konvoy, bot TIR'lar.
- 🦎 Kameleon Saklambaç 3D: renkli 3D oda, bukalemun karakterler. Eşyaya dokun, rengini al, yanına sin. Kıpırdarsan rengin dalgalanır, gözlerin ele verir. Ebe karanlıkta el feneriyle arar, dokunup sobeler. Botlar ve arkadaşla oynanır.

## Bu sürümde (3.7)
- 📹 Zombi Köylü'de arkadaşla sesli ve görüntülü görüşme: 🎤 Ses, 📹 Kamera, 🏠 Aynı oda düğmeleri. Kamera görüntüsü oyuncunun kartında görünür. Yankı önleme açık; "Aynı odadayız" denince iki telefonda da hoparlör ve mikrofon kapanır, böylece yankı ve cızırtı olmaz, görüntü devam eder. (Kamera izni için uygulamaya CAMERA izni eklendi.)
- 🤖 Yapay zekâ oyuncuları sesli konuşuyor: her botun kendi ses tonu (ince, kalın, dede, sincap…), yavaş-orta hız, konuşmalar sırayla ve birbirine girmeden, araya şakalar. Zombi Köylü, Bomba Kedi, İhale ve Saklambaç'ta. Ayarlar → 🤖 Yapay zekâ sesleri ile kapatılabilir.
- 💣 Bomba Kedi'ye yeni kartlar: 🔁 Geri Dön, 🔄 Takas (elini biriyle değiştir), 🙃 Desteyi Çevir, ⬇️ Alttan Çek, 🎯 Hedefli Saldırı. Kedi kartları artık tek kartla birinden kart çalar.
- 🎨 Yeni oyun Renkli Saklambaç: rengini değiştirip aynı renkli zemine karış; ebe el feneriyle arar, dokunup "Sobe!" der. Arkadaşla iki cihazda, boş yerlere bot.
- 🏎️ Yeni oyun Hız Yarışı (NFS tarzı): virajlı, yokuşlu yol, gaz/fren pedalları, direksiyon, 🔥 nitro, vitesle değişen motor sesi, trafik. 🏎️ Spor Araba ya da 🚛 TIR (kornalı). Arkadaşla iki cihazda karşılıklı yarış, boş yerlere bot sürücü. Yarışta ekran yatay döner.
- Android: botlar için ses tonu/hız desteği (speakVoice), kamera izni.

## Bu sürümde (3.6)
- 🏆 İhale Savaşı yeniden tasarlandı: karanlık müzayede salonu, spot ışığında ürün kartı (güce göre mavi/mor/altın parlama), fiyatın etrafında geri sayım halkası, son 3 saniyede tik tak, teklifte altın uçar, satışta tokmak vurur ve kart alıcıya uçar, büyük ➕ / +5 / 🏳️ düğmeleri.
- 🃏 Kart savaşı: karta dokununca hemen atılır (onay yok), her tura 15 sn süre, kartlar ters gelip aynı anda çevrilir, kazanan parlar, +1 uçar.
- ⚔️ Savaşta güç sayacı yükselir, zar döner, kazanan biraz bekletilip açıklanır, gollerde GOOOL yazısı.
- 💣 Bomba Kedi: karta dokununca hemen oynanır (onay düğmesi yok). Rica Et ve kedi çiftinde sadece oyuncuya dokunursun. Sıra sana gelince ses ve titreşim, bomba ihtimali yüksekken kalp atışı sesi.
- 📳 Önemli anlarda telefon titrer (patlama, Hayır!, satış, ısırılma). Ses efektleri kapalıysa titreşim de kapanır.

## Bu sürümde (3.5)
- 🗣️ Ayarlar → Seslendirme: kapatınca bütün oyunlardaki sesli okumalar susar (ses efektleri ayrı ayardan).
- 🧟 Zombi Köylü baştan yazıldı: gece → şafak → sabah → konuşma → oylama → sonuç kendiliğinden geçer, her aşamada geri sayım var. Büyük geçiş ekranları (ay, güneş doğuşu, ısırılan kişi, kart çevirerek rol açma), oyuncuların üstünde konuşma balonları, canlı oy sayımı, emojiler. Yapay zekâ suçlanınca kendini savunur, doktor kurtardığını söyleyebilir. Ekran titremeden, sadece değişen yerler güncellenir.
- 💣 Bomba Kedi WePlay tarzı masa: oyuncular masanın çevresinde, sırası gelenin etrafında 20 sn geri sayım halkası, kartlar uçarak oynanır/çekilir, 🙅 Hayır! kartı ve tepki süresi, Rica Et'te kartı veren seçer, söndürünce bombayı kaydırıcıyla saklarsın, destede bomba ihtimali %, patlama/söndürme animasyonları, emojiler, sonuç sıralaması.

## Bu sürümde (3.4)
- 🎨 Yeni modern görünüm (varsayılan): sade yazı tipi, yumuşak geçişli başlık, ince çerçeveli kartlar, renkli ikon kutuları, büyük harfli bölüm başlıkları, cam efektli oyun düğmeleri. Telefon koyu temadaysa koyu görünür.
- ⚙️ Ayarlar → 🎨 Görünüm: ✨ Modern, 🌙 Koyu ya da 🎈 Renkli (eski çocuk teması).

## Bu sürümde (3.3)
- 👥 Arkadaş ekleme ve ad değiştirme sadece ana sayfada (👥 Arkadaşlarım, ✏️ Adım). Oyunların içinde sadece eklenmiş arkadaşlar çağrılır.
- 🔧 Tamirde vida ve somun sökerken ekran o vidaya yaklaşıyor; tornavida/anahtar dönüyor, vida dışarı çıkıp kutuya uçuyor.
- ✂️ Kâğıtla Etkinlik: evdeki malzemeleri seç, akıllı önerici 36 etkinlikten sana uygun olanı bulur (adım adım, sesli okuma, beğendiklerine göre öğrenir). Blok Dünyası'nda 💡 düğmesi Blok temalı etkinlikler önerir. Öneriler internetsiz, uygulamanın içinde hazırlanır.
- 🧟 Zombi Köylü: gece zombi ısırır, doktor korur, gözcü bakar; gündüz köy konuşur ve oylar. Eksik oyuncuları yapay zekâ oynar (konuşur, şüphelenir, yalan söyleyebilir). Arkadaşla iki cihazda oynanır.
- 💣 Bomba Kedi: kart çek, bomba kediyi çekme! Söndürücü, pas geç, saldır, karıştır, geleceği gör, rica et, kedi çiftleriyle kart çalma. 2-5 oyuncu, eksikler yapay zekâ, arkadaşla oynanır.
- 👫 Birlikte Oyna: harf oyunları, Kitap Oku, Market, Sabır, Kulak Ver, Bebeğimi Giydir, Hafıza ve Devre Kur artık arkadaşla aynı anda oynanıyor (kartlardaki 👫 düğmesi). Doğru cevaplar canlı puan tablosunda yarışır, sesli konuşma ve sohbet açık.

## Bu sürümde (3.2)
- 🐞 Devre Kur’da görevlere dokununca açılmama hatası düzeltildi.
- 🚗🔧 Gerçekçi Araba Tamirhanesi (❤️ 6 can): patlak lastik (bijon, kriko), akü değişimi (önce eksi kutup!), far ampulü, yağ değişimi (tapa, leğen, MAKS çizgisi), motor değişimi (takoz cıvataları, motor vinci).
- 🏠⚡ Yetişkin modunda Ev Elektrik Tesisatı (❤️ 6 can): priz montajı, anahtar ve tavan lambası (buat, klemens), sigorta panosu. Sigortayı kapatmadan kabloya dokunmak, yanlış uca bağlamak, yanlış sigorta seçmek can götürür.
- 🧸 Oyuncak Tamiri (❤️ 6 can): kumandalı araba (pillerin yönü), konuşan ayıcık (lehim).
- 🧱 Blok: 26 yeni blok (granit, mermer, kiremit, parke, fayans, kitaplık, renkli camlar, kabak, karpuz, kaktüs, ametist…), 10 kutulu çubuk, çantada arama ve ⭐ son kullanılanlar, 🎯 dünyadan blok kopyalama, kutuya basılı tutunca çanta açılır, klavye kısayolları (1-0, Q, E, R, M, fare tekerleği).

## Bu sürümde (3.1)
- ⚡ Devre oyununda yaş seçimi: 🧸 7 yaş (renkli, resimli), 🧒 9-10 yaş (Mühendis Çırağı: mavi devre tahtası, ölçü aleti, volt/amper/direnç, seri-paralel, VE/VEYA anahtarları; 8 görev), 🧑‍🔬 Yetişkin (Devre Laboratuvarı: şema sembolleri, canlı V/mA/mW tablosu, Ohm yasası, gerilim bölücü, LED ön direnci, güç, Kirchhoff, motor sürücü; 7 görev). Her yaşın ilerlemesi ayrı tutulur, Araba Tamirhanesi hepsinde var.
- 🧱 Blok: su kapalı bir çukura konunca çukuru konduğu seviyeye kadar tamamen doldurur.
- 💥 Patlat sekmesine 🧹 Alan kır ve 🧱 Alan doldur: iki köşeye dokun, aradaki bloklar kırılır ya da seçtiğin blokla dolar (en fazla 20x20x20).
- 🚗 Arabalar direksiyon ve gaz/fren pedallarıyla sürülüyor (uçak eskisi gibi çubukla).

## Bu sürümde (3.0)
- ⚡ Devre Kur: yeni parçalar (🧯 sigorta, 📯 korna, 🎚️ ışık ayarı, 🌗 ışık sensörü) ve 3 yeni görev (Sigorta korur, Işığı kıs aç, Gece lambası).
- 🚗🔧 Araba Tamirhanesi: 8 bozuk araba. Kopuk far kablosu, patlak ampul, kayıp korna düğmesi, atmış sigorta, ters akü, çalışmayan marş, ters dönen silecek, büyük bakım. Tamir edilince araba çalışıp gidiyor.
- 🧱 Blok: büyük ve küçük arabalarda koltuğa hangi yönden dokunursan dokun, araba farlarının olduğu ön tarafa doğru gider.

## Bu sürümde (2.9)
- 🔨 Tokmak (💥 Patlat sekmesinde): dokunduğun blok basılı tutmadan hemen kırılır, madenler çantaya girer.

## Bu sürümde (2.8)
- Uygulamanın adı **Oyun Dünyası**. Ana ekranın üstünde oyuncunun adıyla “…’ın Oyunu” yazıyor; ✏️ Adım düğmesiyle ad değişiyor.
- 🧱 Blok Dünyası yatay ekranda açılıyor.
- ⛏️ Madenler tek dokunuşla kırılmıyor: basılı tut, ortadaki halka dolunca kırılır. Kömür hızlı, elmas en yavaş.
- ♻️ Çantadaki Maden sekmesinden maden ocağı sıfırlanabiliyor (bütün madenler yerine gelir).
- 🗺️ Harita: önemli yerler, metro durakları ve lego arabalar görünür; birine ya da haritada bir yere dokunup ışınlan.
- 🐄 Hayvanlar: inek, domuz, koyun, tavuk, at, köpek. Gezerler, dokununca ses çıkarıp zıplarlar.
- 💥 Patlat sekmesi: TNT, Süper TNT (dokununca 3 saniye sonra patlar, yan yana olanlar zincirleme patlar), 🚀 roket atar, 🔆 yok edici ışın, ⛏️ dev kazma (3x3 kazar).

## Bu sürümde (2.7)
- 🧱 Blok Dünyası’nda yeni dünya 512x512 (eskisinin 4 katı) ve yerin altı çok derin: mağaralar, kömür, bakır, demir, altın ve elmas madenleri.
- ⛏️ Maden ocağı: dönen merdivenle kuyunun dibine in, tünellerde madenleri kır. Çantadaki ⛏️ Maden sekmesinden meşale, ray, demir/altın/elmas blok, süper motor, süper pil, kristal lamba ve altın kupa yap.
- 🚇 Metro: yolların altında 7 duraklı tren hattı. Durağa merdivenden in, 🚇 Bin’e bas, durakta 🚪 İn.
- 🔧 Tamir atölyesi: kırmızı tezgaha dokun, küçük lego parçalarıyla araba yap (ayna, geri al, hazır arabalar, garaja kaydet), sonra sür. Büyük bloklu arabalar da duruyor.
- 🏢 Fotoğraftaki mavi çizgili apartman: balkonlar, giriş, direk, çit; içinden merdivenle çatıya çıkılıyor.
- 💧 Su artık akıyor: düşer, yayılır, iki kaynak arası dolar, lavı taşa çevirir.
- Eski dünyalar aynen açılır; yenileri görmek için “Yeni dünya”ya bas.

## Bu sürümde (2.6)
- Oyunun adı “Yunus’un Oyunu” oldu (başlık ve telefondaki uygulama adı).

## Bu sürümde (2.5)
- Ayı Adası artık **Macera Adası**: ayı yerine insan kahramanlar (Yusuf, Ali, Elif, Deniz). Yüzleri, saçları, kıyafetleri ve sırt çantaları var; koşarken dizler ve dirsekler bükülüyor.
- **Kenara tutunma**: zıplayınca eller kenara değerse tutunur; ⬆️ ya da ileri itince tırmanır, geri çekince bırakır, sağa sola kayabilir.
- Çift zıplamada takla, uzun basınca daha yüksek zıplama, yumuşak hızlanma, kenardan düşerken kısa süre zıplayabilme.
- Bölümler daha zor ve çeşitli: tırmanma sütunları, dönen dikenli kütük, ateş fıskiyeleri, etrafında dönen platformlar, asansör, sallanan ip köprü, kovalayan düşmanlar.
- Yeni 4. bölüm **Volkan Adası** (3 Altın Bal ile açılır), sonunda dev canavar: duvara çarpınca sersemler, o zaman kafasına zıpla.

## Bu sürümde (2.4)
- 🎨 Çiz, Tahmin Et puanı: doğru bilen 3 puan, her yanlış tahmin 1 puan eksiltir (en az 1), çizen 1 puan. Doğru/yanlış sayıları skorda ve oyun sonunda görünür.

## Bu sürümde (2.3)
- 🎥 Araçta kamera: ekranı kaydırarak araç etrafında dön, yukarı/aşağı bak; 🎥 düğmesiyle Arkadan / Uzaktan / Önden bak / Yukarıdan.

## Bu sürümde (2.2)
- 🐻 Ayı Adası daha gerçekçi: güneşe göre gerçek gölgeler, ayıda kürk dokusu, yapraklarda ve çimende ayrıntı.
- 🗣️ Seslendirme: gereksiz konuşmalar kaldırıldı, aynı cümle tekrar tekrar okunmuyor; emojiler okunmuyor; en doğal Türkçe ses seçiliyor.
- 🧱 Blok Dünyası: yeni dünya 256x256 (eskisinin 4 katı); yollar, şehir, otopark, benzinlik, çiftlik, uzun pistli havalimanı, deniz kenarı.
- 🚛 Yeni araçlar: TIR, otobüs, itfaiye, polis, taksi, ambulans, spor araba, traktör. Sürüş daha stabil, yolda daha hızlı.

## Bu sürümde (2.1)
- 🐻 Ayı Macerası: adadaki mor kapılardan 3 bölüme gidilir (Çiçekli Orman, Karlı Tepeler, Kum Çölü).
- Uçan adalar, hareketli ve çöken platformlar, zıplatıcılar, düşmanlar (üstüne zıpla ya da 🌀 dön), sandıklar, 3 can kalbi, kontrol bayrakları.
- Her bölümde 3 kayıp civciv ve sonunda Altın Bal. Altın Bal sonraki kapıyı açar.
- 🎩 Şapka Dükkânı: toplanan paralarla 7 şapka; ayının başında görünür. Paralar artık kaydediliyor.

## Bu sürümde (2.0)
- 📖 Kitap Oku: yazıyı sesli oku, doğru okunan kelime yeşil olur. 15 kitap + kelime okuma. Telefonun konuşma tanıma motorunu kullanır (Google uygulaması gerekir).
- 🐻 Ayı Adası yenilendi: gökyüzü, dalgalı deniz, çimen, çiçekler, kelebekler, gölgeler, yeni evler.
- Adada yeni oyunlar: ⚽ Futbol (arkadaşla da), 🏁 Yarış, 🎈 Balon Patlatma, 📖 Kitap Evi.

## Bu sürümde (1.9)
- 🐻 Ayı Adası: ayınla adayı gez, evlerin kapısından oyunlara gir, arkadaşınla birlikte gez.
- 👫 Arkadaş listesi: arkadaşını bir kere ekle, sonra adına dokunup çağır. Kod yazmak yok.
- 🔄 Bağlantı koparsa kendiliğinden yeniden bağlanır; uygulama kapanırsa menüde "oyuna geri dön" çıkar.
- 🎤 Sesli konuşma ve 💬 sohbet (Kelime Zinciri, Taş Kağıt Makas). Uygulama ilk seferde mikrofon izni ister.
- 🧱 Blok Dünyası karşılıklı oynanıyor; yeni dünya 4 kat büyük: havalimanı, stadyum, havuz, göl, yanardağ, bilim parkı.

## Bu sürümde (1.8)
- Uygulama tam ekran açılıyor: durum çubuğu ve alt tuşlar gizli (kenardan kaydırınca görünür).

## Bu sürümde (1.7)
- Çiz, Tahmin Et: kolay/orta/zor seviyeler (300 kelime), seçeneksiz oyun (yazarak ya da sesli + Doğru/Yanlış/Pas), 10–180 sn süre.

## Bu sürümde (1.6)
- Yeni **Çiz, Tahmin Et**: iki cihazda canlı çizim ya da aynı cihazda sırayla.

## Bu sürümde (1.5)
- İhale Savaşı’na **Kart savaşı** eklendi; hayvan ve canavar sayısı 100’e çıktı; para ve süreler kurulum ekranından ayarlanıyor.

## Bu sürümde (1.4)
- Yeni **Blok Dünyası**: 3D açık dünya. Blok koy/kır, elektrik devresi kur, bloklardan araba ve uçak yapıp bin.

## Bu sürümde (1.3)
- Yeni **Küçük Mucit · Devre Kur**: 12 görev ve serbest atölye. Kablo çek, ampul yak, pervane döndür, zil çal.

## Bu sürümde (1.2)
- Bebeğimi Giydir artık 3D. İnternetsiz çalışır, parmakla kaydırınca bebek döner.
- Yeni **İhale Savaşı** modu: bilgisayara karşı, aynı cihazda iki kişi ya da iki cihazla oda koduyla.
- İki cihazlı oyun için iki telefonun da internete bağlı olması gerekir (aynı Wi-Fi en iyisi). Diğer her şey internetsiz çalışır.

## Yol 1: GitHub ile (bilgisayar gerekmez, telefondan da olur)
1. github.com adresinde ücretsiz bir hesap aç.
2. Sağ üstteki **+** → **New repository** de, bir ad ver (örnek: yusuf-oyun) ve **Create repository**'ye bas.
3. Açılan sayfada **uploading an existing file** bağlantısına bas. Bu klasördeki **her şeyi** (gizli `.github` klasörü dahil) sürükleyip bırak, sonra **Commit changes**'e bas.
   - `.github` klasörü yüklenmezse: **Add file → Create new file** de, ad kısmına `.github/workflows/apk.yml` yaz ve bu klasördeki aynı dosyanın içeriğini yapıştır.
4. Üstteki **Actions** sekmesine geç. “APK oluştur” işi 3–5 dakikada biter (yeşil tik).
5. İşin üstüne tıkla, en alttaki **Artifacts** bölümünden **yusuf-emirin-oyunu-apk**'yı indir. ZIP'i açınca içinden `app-debug.apk` çıkar.

## Yol 2: Android Studio ile
1. Android Studio'yu kur ve **Open** ile bu klasörü aç.
2. Gradle eşitlemesi bitince **Build → Build APK(s)**'ye bas.
3. APK şurada olur: `app/build/outputs/apk/debug/app-debug.apk`

## Telefona kurmak
APK'yı telefona at ve dokun. “Bilinmeyen kaynaklardan yükleme” izni sorarsa izin ver.
Play Store dışından kurulduğu için Play Protect uyarı gösterebilir, **Yine de yükle** demen yeterli.

## Sesli okuma çalışmazsa
Ayarlar → Erişilebilirlik (veya Sistem → Dil) → **Metin okuma çıkışı** → Google Konuşma Hizmetleri → Türkçe ses verisini indir.

## 3.17
- LEGO: 348 modellik katalog (uçaklar dahil, renkli ve "tek renk" modeller), Lego modunda ← geri tuşu düzeldi.
- ZOMBİ: 3 mod — Standart, Eğlence (Among Us tarzı: odalar, görevler, vampir, adli tıp, mühendis, izci, keskin nişancı, joker) ve Feign tarzı (gece yetenekleri: zombi, vampir, sabotajcı, doktor, gözcü, bekçi, adli tıp, mühendis, izci, nişancı, joker).
