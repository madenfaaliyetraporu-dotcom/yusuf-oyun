# Yusuf Emir’in Oyunu – Android uygulaması

Bu klasör hazır bir Android projesidir. İçinde oyunun kendisi (`app/src/main/assets/index.html`) ve onu telefonda açan küçük bir uygulama var. Sesli okuma telefonun kendi Türkçe ses motoruyla çalışır. Oyun internetsiz de oynanır.

## Bu sürümde (1.2)
- Bebeğimi Giydir artık 3D. İnternetsiz çalışır, parmakla kaydırınca bebek döner.
- Yeni **İhale Savaşı** modu: bilgisayara karşı, aynı cihazda iki kişi ya da iki cihazla oda koduyla.
- İki cihazlı oyun için iki telefonun da internete bağlı olması gerekir (aynı Wi-Fi en iyisi). Diğer her şey internetsiz çalışır.

## Yol 1: GitHub ile (bilgisayar gerekmez, telefondan da olur)
1. github.com adresinde ücretsiz bir hesap aç.
2. Sağ üstteki **+** → **New repository** de, bir ad ver (örnek: yusuf-oyun) ve **Create repository**'ye bas.
3. Açılan sayfada **uploading an existing file** bağlantısına bas. Bu klasördeki **her şeyi** (gizli `.github` klasörü dahil) sürükleyip bırak, sonra **Commit changes**'e bas.
   - `.github` klasörü yüklenmezse: **Add file → Create new file** de, ad kısmına `.github/workflows/apk.yml` yaz ve bu klasördeki aynı dosyanın içeriğini yapıştır.
4. Üstteki **Actions** sekmesine geç. “APK oluştur” işi 3–5 dakikada biter (yeşil tik).
5. İşin üstüne tıkla, en alttaki **Artifacts** bölümünden **yusuf-emirin-oyunu-apk**'yı indir. ZIP'i açınca içinden `app-debug.apk` çıkar.

## Yol 2: Android Studio ile
1. Android Studio'yu kur ve **Open** ile bu klasörü aç.
2. Gradle eşitlemesi bitince **Build → Build APK(s)**'ye bas.
3. APK şurada olur: `app/build/outputs/apk/debug/app-debug.apk`

## Telefona kurmak
APK'yı telefona at ve dokun. “Bilinmeyen kaynaklardan yükleme” izni sorarsa izin ver.
Play Store dışından kurulduğu için Play Protect uyarı gösterebilir, **Yine de yükle** demen yeterli.

## Sesli okuma çalışmazsa
Ayarlar → Erişilebilirlik (veya Sistem → Dil) → **Metin okuma çıkışı** → Google Konuşma Hizmetleri → Türkçe ses verisini indir.
